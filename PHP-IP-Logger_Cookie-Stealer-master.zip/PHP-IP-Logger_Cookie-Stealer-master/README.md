#PHP IP Logger and Cookie Stealer
By: BlackVikingPro

Description
___________

This php script simply logs anyones ip address, user agent, and some more data
and then logs it into "log.txt", then redirects the user in 5 seconds claiming
it is really only a "Error 420: Fuck You!!". However, this script is completely
developer friendly, anyone can use it, and if you mess something up, it's a very
simple fix.

Websites
________

Personal: https://blackvikingpro.com

Personal, Contact: https://blackvikingpro.com/?page=contact

#Demo
#____

> https://blackvikingpro.com/hackthis/
(Put a "index.php" at end of this url if it brings back a 404)